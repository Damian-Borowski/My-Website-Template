var numer = 8;
var numer2 = 4;

var wynik = 100 + numer2;
